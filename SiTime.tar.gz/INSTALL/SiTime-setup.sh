#!/bin/bash
# Generated Date: 2025-02-23 10:07:50

# reset locale to the default locale
unset LC_ALL LANG LC_CTYPE LC_COLLATE LC_NUMERIC LC_TIME LC_MONETARY LC_MESSAGES
export LC_ALL=C
export LANG=C

if [ -z "$SiTime_INSTALL_DIR" ]; then \

    echo "ERROR: SiTime Installation Directory is NOT specified. Please set the SiTime_INSTALL_DIR shell variable to the Installation path."; 

else
    export LD_PRELOAD=$SiTime_INSTALL_DIR/freetype-2.6.5/INSTALLED/lib/libfreetype.so.6;
    
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$SiTime_INSTALL_DIR/lib
    
    echo "SiTime Setup Complete.";
fi
